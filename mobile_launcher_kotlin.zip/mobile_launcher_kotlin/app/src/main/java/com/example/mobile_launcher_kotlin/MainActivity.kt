package com.example.mobile_launcher_kotlin

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.NetworkInfo
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.support.design.widget.Snackbar
import android.support.design.widget.NavigationView
import android.support.v4.view.GravityCompat
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import android.support.v4.widget.DrawerLayout
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.widget.Toast
import com.example.mobile_launcher_kotlin.databinding.ActivityMainBinding
import java.lang.Exception
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.appBarMain.fab.setOnClickListener {
            findNavController(R.id.nav_host_fragment_content_main)
                .navigate(R.id.homeFragment)
        }
        val drawerLayout: DrawerLayout = binding.drawerLayout
        val navView: NavigationView = binding.navView
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow
            ), drawerLayout
        )
//        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)


        binding.imgProfile.setOnClickListener{
            drawerLayout.openDrawer(GravityCompat.START);
        }
        binding.appBarMain.bottomNavigationView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.city_guide -> {
                    findNavController(R.id.nav_host_fragment_content_main)
                        .navigate(R.id.guideFragment)
                }

                R.id.apps -> {
                    findNavController(R.id.nav_host_fragment_content_main)
                        .navigate(R.id.appsFragment)
                }

                R.id.call -> {
                    findNavController(R.id.nav_host_fragment_content_main)
                        .navigate(R.id.callsFragment)
                }
                R.id.basket -> {
                    findNavController(R.id.nav_host_fragment_content_main)
                        .navigate(R.id.basketFragment)
                }
            }
            true
        }

        thread {
            while (true) {
                val deviceOnline = isDeviceOnline(this.applicationContext)
                Log.d("khalil", "deviceOnline $deviceOnline")

                Thread.sleep(1000)
            }
        }

    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }

    private fun isDeviceOnline(context: Context): Boolean {
        val connManager = context.getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val networkCapabilities = connManager.getNetworkCapabilities(connManager.activeNetwork)
            if (networkCapabilities == null) {
                Log.d("khalil", "Device Offline")
                return false
            } else {
                Log.d("khalil", "Device Online")
                if (networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                    networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) &&
                    networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_SUSPENDED)
                ) {
                    Log.d("khalil", "Connected to Internet")
                    return true
                } else {
                    Log.d("khalil", "Not connected to Internet")
                    return false
                }
            }
        } else {
            // below Marshmallow
            val activeNetwork = connManager.activeNetworkInfo
            if (activeNetwork?.isConnectedOrConnecting == true && activeNetwork.isAvailable) {
                Log.d("khalil", "Device Online")
                when (activeNetwork.state) {
                    NetworkInfo.State.CONNECTED -> {
                        Log.d("khalil", " CONNECTED ")
                        return true
                    }
                    NetworkInfo.State.CONNECTING -> {
                        Log.d("khalil", " CONNECTING ")
                        return true
                    }
                    else -> {
                        Log.d("khalil", "NO Connection")
                        return false
                    }
                }
            } else {
                Log.d("khalil", "Device Offline")
                return false
            }
        }
    }
}